
function val(){
    var name= document.getElementById("name").value;
    var email= document.getElementById("email").value;
    var error= document.getElementById("error_message");
    var text;
    error.style.padding = "10px";

    if(name.length ==""){
        text = "Name Should'nt be empty";
        error.innerHTML = text;
        return false;
    }
    if(email.indexOf("@") == -1 || email.length < 6){
        text = "Your email is invalid.";
        error_message.innerHTML = text;
        return false;
    }
   if(panCard.length < 10){
        text = "Pancard number Should be 10 characters";
        error.innerHTML = text;
        return false;
    }
    if(pass != cpass){
        text = "Password does not match";
        error.innerHTML = text;
        return false;
    }
    var frm = document.getElementById("myform");
    frm.style.display = 'none';
    var hid = document.getElementById("hid");
    hid.style.display = 'none';
    var disp = document.getElementById("success");
    disp.style.display = 'block';
    error.style.padding = "0px";
    return false;
}
  
  
  

